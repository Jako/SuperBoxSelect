<?php
/**
 * Setting Lexicon Entries for SuperBoxSelect
 *
 * @package superboxselect
 * @subpackage lexicon
 */
$_lang['setting_superboxselect.advanced'] = 'Расширенный';
$_lang['setting_superboxselect.advanced_desc'] = 'Показать дополнительные настройки телевизора (например, шаблон поля).';
$_lang['setting_superboxselect.debug'] = 'Отладка';
$_lang['setting_superboxselect.debug_desc'] = 'Записывать отладочную информацию в лог ошибок MODX.';
